select * from Emp where empNo=1111;


create sequence emp_seq start with 1 increment by 1;

select * from emp where comm>0;