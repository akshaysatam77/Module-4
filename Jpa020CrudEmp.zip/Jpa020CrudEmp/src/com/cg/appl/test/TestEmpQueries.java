package com.cg.appl.test;

import java.util.List;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.services.EmpServices;
import com.cg.appl.services.EmpServicesImpl;

public class TestEmpQueries {

	public static void main(String[] args) {
		
		try {
			EmpServices services = new EmpServicesImpl();
			
			List<Emp> empList = services.getEmpOnSal(2000f, 4000f);
			
			//empList.forEach(System.out::print)
			
			for(Emp emp : empList){
				System.out.println(emp);
			}
			
			
		/*	
			Emp emp = new Emp();
			
			emp.setEmpNm("bbbb");
			emp.setEmpSal(2000f);
			emp = services.admitNewEmp(emp);
			System.out.println(emp);
			
			*/
		/*	
			List<Emp> empList = services.getEmpsForCommission();
			for(Emp emp : empList)
			{
				System.out.println(emp);
			}*/
			
		} catch (EmpException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
