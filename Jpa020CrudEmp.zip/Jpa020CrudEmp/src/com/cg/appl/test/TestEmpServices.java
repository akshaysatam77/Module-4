package com.cg.appl.test;

import java.util.List;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.services.EmpServices;
import com.cg.appl.services.EmpServicesImpl;

public class TestEmpServices {

	public static void main(String[] args) {
		
		try {
			EmpServices services = new EmpServicesImpl();
			/*Emp emp = services.getEmpDetails(7499);
			System.out.println(emp);*/
			
		/*	List<Emp>empList = services.getEmpList();
			for(Emp emp : empList){
				System.out.println(emp);*/
			//}
			
			/*Emp emp = new Emp();
			emp.setEmpNo(1111);
			emp.setEmpNm("aaaaaa");
			emp.setEmpSal(5000f);
			
			services.admitNewEmp(emp);*/
			
			
			//System.out.println(services.getEmpDetails(1111));
			

			//services.updateName(1111, "bbbb");
			
			/*Emp emp = new Emp();  //Transient object
			emp.setEmpNo(1111);
			emp.setEmpNm("cccc");
			emp.setEmpSal(6000f);
			services.updateEmp(emp);*/
			
			services.deleteEmp(1111);
			System.out.println( services.getEmpDetails(1111));
			
		} catch (EmpException e) {
			
			e.printStackTrace();
		}
		

	}

}
