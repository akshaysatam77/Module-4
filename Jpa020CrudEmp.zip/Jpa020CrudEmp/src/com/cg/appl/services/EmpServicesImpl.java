package com.cg.appl.services;

import java.util.List;

import com.cg.appl.daos.EmpDao;
import com.cg.appl.daos.EmpDaoImpl;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;

public class EmpServicesImpl implements EmpServices {
	
	private EmpDao dao;
	
	public EmpServicesImpl() throws EmpException{
		dao=new EmpDaoImpl();
		
	}

	@Override
	public Emp getEmpDetails(int empNo) throws EmpException {
		
		return dao.getEmpDetailsSafe(empNo);
	}

	@Override
	public List<Emp> getEmpList() throws EmpException {
		
		return dao.getEmpList();
	}

	@Override
	public Emp admitNewEmp(Emp emp) throws EmpException {
		
		return dao.admitNewEmp(emp);
	}

	@Override
	public boolean updateName(int empNo, String newName) throws EmpException {
		
		return dao.updateName(empNo, newName);
	}

	@Override
	public boolean updateEmp(Emp emp) throws EmpException {
		
		return dao.updateEmp(emp);
	}

	@Override
	public boolean deleteEmp(int empNo) throws EmpException {
		
		return dao.deleteEmp(empNo);
	}

	@Override
	public List<Emp> getEmpOnSal(Float from, Float to) throws EmpException {
		
		return dao.getEmpOnSal(from, to);
	}

	@Override
	public List<Emp> getEmpsForCommission() throws EmpException {
		
		return dao.getEmpsForCommission();
	}
}
