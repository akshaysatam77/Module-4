package com.cg.appl.daos;

import java.util.List;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;

public interface EmpDao {
	
	Emp getEmpDetailsSafe(int empNo) throws EmpException;
	List<Emp> getEmpList() throws EmpException;
	Emp admitNewEmp(Emp emp)  throws EmpException;
	boolean updateName(int empNo, String newName)throws EmpException;
	boolean updateEmp(Emp emp) throws EmpException;
	boolean deleteEmp(int empNo)  throws EmpException;
	List<Emp> getEmpOnSal(Float from, Float to) throws EmpException;
	List<Emp> getEmpsForCommission() throws EmpException;
}
