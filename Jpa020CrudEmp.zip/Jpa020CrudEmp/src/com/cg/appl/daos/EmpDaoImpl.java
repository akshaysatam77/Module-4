package com.cg.appl.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.RollbackException;
import javax.persistence.TypedQuery;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.util.EntityManageUtil;

public class EmpDaoImpl implements EmpDao {
	
	private EntityManageUtil util;
	private EntityManager manager;
	
	public  EmpDaoImpl() throws EmpException{
		
		util = new EntityManageUtil();
		manager = util.getManager();
	}

	
	
	private Emp getEmpDetails(int empNo) throws EmpException {
		Emp emp = manager.find(Emp.class, empNo);
		if(emp==null){
			throw new  EmpException("Wrong empNo");
		}
		return emp;
	}
	
	@Override
	public Emp getEmpDetailsSafe(int empNo) throws EmpException {
		Emp emp = manager.find(Emp.class, empNo);
		if(emp==null){
			throw new  EmpException("Wrong empNo");
		}
		manager.detach(emp);
		return emp;
	}
	
	@Override
	public List<Emp> getEmpList() throws EmpException {
		try {
			TypedQuery<Emp> qry = manager.createNamedQuery("qryAllEmps",Emp.class);
			List<Emp> empList = qry.getResultList();
			return empList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new EmpException("Improper query fabrication",e); 
		}
	}

	@Override
	public Emp admitNewEmp(Emp emp) throws EmpException {
		try {
			manager.getTransaction().begin();
			manager.persist(emp);
			manager.getTransaction().commit();
		} catch (RollbackException e) {
			
		throw new EmpException("Violated: column size or constrain",e);
		}
		return emp;
		
	}
	
	@Override
	public boolean updateName(int empNo, String newName) throws EmpException {
		try {
			manager.getTransaction().begin();
			Emp emp = this.getEmpDetails(empNo);
			emp.setEmpNm(newName);
			manager.getTransaction().commit();
			return true;
		} catch (RollbackException e) {
			throw new EmpException("Failed: Name updation",e);
		}
	}
	
	@Override
	public boolean updateEmp(Emp emp) throws EmpException {
		try {
			manager.getTransaction().begin();
		  	
		    manager.merge(emp);
		    System.out.println("*****");
		    
			manager.getTransaction().commit();
			return true;
		} catch (RollbackException e) {
			throw new EmpException("Failed: Name updation",e);
		}
	}
	

	@Override
	public boolean deleteEmp(int empNo) throws EmpException {
		
		try {
			manager.getTransaction().begin();
		  	Emp emp = this.getEmpDetails(empNo);
		    manager.remove(emp);
		    System.out.println("*****");
		    
			manager.getTransaction().commit();
			return true;
		} catch (RollbackException | EmpException e) {
			throw new EmpException("Failed: Name updation",e);
		}
		
	
	}
	
	
	@Override
	public List<Emp> getEmpOnSal(Float from, Float to) throws EmpException {
		String qryStr = "select e from employee e where empSal between :from and :to";
		TypedQuery<Emp> qry = manager.createNamedQuery("qryEmpsOnSal", Emp.class);
		
		qry.setParameter("from", from);
		qry.setParameter("to", to);
		return qry.getResultList();
	}
	
	
	@Override
	public List<Emp> getEmpsForCommission() throws EmpException {
		TypedQuery<Emp> qry = manager.createNamedQuery("qryEmpsComm",Emp.class);
		return qry.getResultList();
	
	}
	@Override
	protected void finalize() throws Throwable {
		util.closeFactory();
		super.finalize();
	}




	}

