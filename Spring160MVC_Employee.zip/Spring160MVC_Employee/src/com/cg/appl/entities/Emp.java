package com.cg.appl.entities;

import java.io.Serializable;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity(name="employee")
@Table(name="EMP")
@NamedQueries({
	
			
			@NamedQuery(name="qryAllEmps",query="select e from employee e")
		
})

@SequenceGenerator(name="emp_generate", sequenceName="EMP_SEQ", allocationSize=1, initialValue=1)
public class Emp implements Serializable {
	
	private int empNo;
	private String empNm;
	private float empSal;
	private Float commission;
	private Float totalSalary;
	@Id
	@Column(name="EMPNO")
	@GeneratedValue(generator="emp_generate", strategy=GenerationType.SEQUENCE)
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	
	@Column(name="ENAME")
	@NotEmpty(message="Name is Mandatory")
	@Size(min=3,max=10,message="Name should be between 3-10 characters")
	public String getEmpNm() {
		return empNm;
	}
	public void setEmpNm(String empNm) {
		this.empNm = empNm;
	}
	
	@Column(name="SAL")
	public float getEmpSal() {
		return empSal;
	}
	
	
	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}
	
	@Column(name="COMM")
	public Float getCommission() {
		return commission;
	}
	public void setCommission(Float commission) {
		this.commission = commission;
	}
	
	
	//@Column(name="SAL+COMM")
	@Transient
	public Float getTotalSalary() {
		return getEmpSal() + (getCommission()==null ? 0 : getCommission());
	}
	public void setTotalSalary(Float totalSalary) {
		this.totalSalary = totalSalary;
	}
	@Override
	public String toString() {
		return "Emp [empNo=" + empNo + ", empNm=" + empNm + ", empSal="
				+ empSal + ", commission=" + commission + ", totalSalary="
				+ getTotalSalary()+"]";
	}
	
	
	
}
