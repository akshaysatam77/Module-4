package com.cg.appl.services;

import java.util.List;


import com.cg.appl.entities.Emp;

import com.cg.appl.exceptions.EmpException;


public interface EmpServices {
	Emp getEmpDetails(int empId) throws EmpException;
	List<Emp> getAllEmps() throws EmpException;
	Emp addNewEmp(Emp emp) throws EmpException;
	Emp updateEmp(Emp emp) throws EmpException;
	boolean deleteData(int empNo) throws EmpException;
}
