package com.cg.appl.services;

import java.util.List;



import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.appl.daos.EmpDao;

import com.cg.appl.entities.Emp;

import com.cg.appl.exceptions.EmpException;



@Service("empService")
@Transactional
public class EmpServicesImpl implements EmpServices {

	private EmpDao dao;
	
	@Resource(name="empDao")
	public void setTraineeDao(EmpDao dao){
		this.dao = dao;
	}
	
	

	@Override
	public Emp getEmpDetails(int empId) throws EmpException {
		
		return dao.getEmpDetails(empId);
	}

	@Override
	public List<Emp> getAllEmps() throws EmpException {
		
		return dao.getAllEmps();
	}

	
	@Override
	public Emp updateEmp(Emp emp) throws EmpException {
		
		return dao.updateEmp(emp);
	}
	@Override
	public Emp addNewEmp(Emp emp) throws EmpException {
	
		return dao.addNewEmp(emp);
	}



	@Override
	public boolean deleteData(int empNo) throws EmpException {
		
		return dao.deleteData(empNo);
	}


}
