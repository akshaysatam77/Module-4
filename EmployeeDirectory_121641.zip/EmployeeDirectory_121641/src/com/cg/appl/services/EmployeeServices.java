package com.cg.appl.services;

import java.util.List;

import com.cg.appl.entities.Employee;
import com.cg.appl.exceptions.EmployeeException;

public interface EmployeeServices {

	Employee addNewEmployee(Employee emp) throws EmployeeException;
	List<Employee> getAllEmployees() throws EmployeeException;
}
