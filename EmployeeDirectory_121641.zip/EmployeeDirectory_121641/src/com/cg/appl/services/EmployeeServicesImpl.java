package com.cg.appl.services;

import java.util.List;


import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.appl.daos.EmployeeDao;
import com.cg.appl.entities.Employee;
import com.cg.appl.exceptions.EmployeeException;


@Service("employeeService")
@Transactional
public class EmployeeServicesImpl implements EmployeeServices {

	private EmployeeDao dao;
	
	@Resource(name="employeeDao")
	public void setEmployeeDao(EmployeeDao dao){
		this.dao = dao;
	}
	
	@Override
	public Employee addNewEmployee(Employee emp) throws EmployeeException {
		
		return dao.addNewEmployee(emp);
	}

	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		
		return dao.getAllEmployees();
	}

}
