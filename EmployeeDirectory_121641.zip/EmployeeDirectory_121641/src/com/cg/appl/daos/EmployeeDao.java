package com.cg.appl.daos;

import java.util.List;

import com.cg.appl.entities.Employee;
import com.cg.appl.exceptions.EmployeeException;

public interface EmployeeDao {

	Employee addNewEmployee(Employee emp) throws EmployeeException;
	List<Employee> getAllEmployees() throws EmployeeException;
}
