package com.cg.appl.daos;

import java.util.List;


import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.RollbackException;

import org.springframework.stereotype.Repository;


import com.cg.appl.entities.Employee;
import com.cg.appl.exceptions.EmployeeException;

@Repository("employeeDao")
public class EmployeeDaoImpl implements EmployeeDao {

	private EntityManagerFactory factory;
	
	@Resource(name="entityMFactory")
	public void setEntityMFactory(EntityManagerFactory factory) {
		this.factory = factory;
		
	}

	@Override
	public Employee addNewEmployee(Employee emp) throws EmployeeException {
		
		EntityManager manager = factory.createEntityManager();
		
		try {
			System.out.println(emp);
			EntityTransaction trans = manager.getTransaction();
			trans.begin();
			manager.persist(emp);
			trans.commit();
		} catch (RollbackException e) {
			
			throw new EmployeeException("Record Not Committed",e);
		}
		
		return emp;
	}

	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		
		EntityManager manager = factory.createEntityManager();
		Query qry = manager.createNamedQuery("qryAllEmps", Employee.class);
		return qry.getResultList();
		
	}

}
