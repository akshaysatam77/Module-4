package com.cg.appl.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Employee;
import com.cg.appl.exceptions.EmployeeException;
import com.cg.appl.services.EmployeeServices;

@Controller
public class EmployeeController {
	
	private EmployeeServices services;
	
	private List<String>designations;
	
	@PostConstruct
	public void initialize(){
		
		designations=new ArrayList<>();
		designations.add("Software Engineer");
		designations.add("Senior Software Engineer");
		designations.add("Team Lead");
		designations.add("Manager");
	}
	
	@Resource(name="employeeService")
	public void setEmployeeServices(EmployeeServices services){
		this.services = services;
	}
	
	@RequestMapping("/welcome.do")
    public ModelAndView getWelcomePage(){
		
		System.out.println("In controlling method");
		ModelAndView model = new ModelAndView("welcome");
		
		return model;
		
	}
	
	@RequestMapping("/entryForm.do")
	public ModelAndView getEntryForm(){
		
		ModelAndView model = new ModelAndView("entryForm");
		model.addObject("employee", new Employee());
		model.addObject("designations", designations);
		return model;
	}
	
	@RequestMapping("/submitEntryForm.do")
	public ModelAndView submitEntryForm(@ModelAttribute @Valid Employee emp, BindingResult result){
	
		 ModelAndView model=new ModelAndView();
		 if(result.hasErrors()){
		    	model.setViewName("entryForm");
		    	model.addObject("employee", emp);
				model.addObject("designations", designations);
		    	return model;
		 }
		 
		 try {
			Employee empResponse = services.addNewEmployee(emp);
			 
			 model.setViewName("successInsert");
			 model.addObject("employee", empResponse);
			 
		} catch (EmployeeException e) {
			model.setViewName("error");
			model.addObject("errMsg", "Record Insertion Failed: " +e.getMessage());
		}
			return model;
		 
	}

	@RequestMapping("/listAllEmployees.do")
	public ModelAndView listAllEmployees(){
		ModelAndView model = null;
		
		try {
			List<Employee> emps = services.getAllEmployees();
			model = new ModelAndView("listAllEmployees");
			model.addObject("employees", emps);
		} catch (EmployeeException e) {
			model = new ModelAndView("error");
			model.addObject("errMsg", e.getMessage());
		}
		return model;
	}
}
