package com.cg.appl.entities;

import java.io.Serializable;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity(name="employee")
@Table(name="EMPLOYEE")
@NamedQueries({
	
	
	@NamedQuery(name="qryAllEmps",query="select e from employee e")

})

@SequenceGenerator(name="emp_generate", sequenceName="HIBERNATE_SEQUENCE", allocationSize=1, initialValue=1000)
public class Employee implements Serializable {

	private static final long serialVersionUID = 1L;

	private int empId;
	private String empNm;
	private String gender;
	private String designationNm;
	private String email;
	private String phone;
	
	@Id
	@Column(name="EMPLOYEE_CODE")
	@GeneratedValue(generator="emp_generate", strategy=GenerationType.SEQUENCE)
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	
	@Column(name="EMPLOYEE_NAME")
	@NotEmpty(message="Name required")
	@Size(max=40,message="Too Large")
	public String getEmpNm() {
		return empNm;
	}
	public void setEmpNm(String empNm) {
		this.empNm = empNm;
	}
	
	@Column(name="EMPLOYEE_GENDER")
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	@Column(name="DESIGNATION_NAME")
	public String getDesignationNm() {
		return designationNm;
	}
	public void setDesignationNm(String designationNm) {
		this.designationNm = designationNm;
	}
	
	@Column(name="EMPLOYEE_EMAIL")
	@Email
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Column(name="EMPLOYEE_PHONE")
	@Pattern(regexp="[1-9]{1}[0-9]{9}",message="Incorrect")
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empNm=" + empNm + ", gender="
				+ gender + ", designationNm=" + designationNm + ", email="
				+ email + ", phone=" + phone + "]";
	}
	
}
