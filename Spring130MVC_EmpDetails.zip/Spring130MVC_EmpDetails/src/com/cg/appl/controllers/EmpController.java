package com.cg.appl.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class EmpController {
	
	@RequestMapping("/login.do")
	public ModelAndView showLoginPage(){
		
		ModelAndView model = new ModelAndView("login");
		
		return model;

	}
	
	@RequestMapping("/authenticate.do")
	public ModelAndView authenticate(@RequestParam long empid){
		System.out.println(empid);
		ModelAndView model = new ModelAndView();
		
		model.addObject("empid",empid);
		model.setViewName("success");
		return model;
		
	}
}
