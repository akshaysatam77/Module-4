select * from TRAINEE;

create sequence trainee_seq start with 1 increment by 1 nocycle;
drop sequence trainee_seq;

create sequence trainee_seq start with 1100 increment by 1 nocycle;