package com.cg.appl.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;


@Entity(name="trainee")
@Table(name="TRAINEE")
@SequenceGenerator(name="trainee_generate", sequenceName="TRAINEE_SEQ", allocationSize=1, initialValue=1)
public class Trainee {

	private int traineeId;
	private String traineeName;
	private String traineeDomain;
	private String traineeLocation;
	public Trainee() {
		super();
	}
	
	@Id
	@Column(name="TRAINEEID")
	@GeneratedValue(generator="trainee_generate", strategy=GenerationType.SEQUENCE)
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	
	@NotEmpty(message="Name is required.")
	@Size(min=1, max=10, message="Name must be of size 1 to 10")
	@Column(name="TRAINEENAME")
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	
	@Column(name="TRAINEEDOMAIN")
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}
	
	@Column(name="TRAINEELOCATION")
	public String getTraineeLocation() {
		return traineeLocation;
	}
	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}
	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId + ", traineeName="
				+ traineeName + ", traineeDomain=" + traineeDomain
				+ ", traineeLocation=" + traineeLocation + "]";
	}
	
	
	
}
