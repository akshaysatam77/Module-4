package com.cg.appl.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


// http://localhost:8085/Spring120MVC_Login/login.do
@Controller
public class LoginController {

	// Give Login.jsp
	
	@RequestMapping("/login.do")
	public ModelAndView showLoginPage(){
		
		ModelAndView model = new ModelAndView("login");
		
		
		return model;
		
		
	}
	
	
	// Do authentication
	
/*	@RequestMapping("/authenticate.do")
	public ModelAndView authenticate(HttpServletRequest req, HttpServletResponse resp){
		
		
		System.out.println(req.getParameter("username"));
		System.out.println(req.getParameter("password"));
		
		
		ModelAndView model = new ModelAndView("success");
		
		return model;
	}*/
	
	@RequestMapping("/authenticate.do")
	public ModelAndView authenticate(@RequestParam String username, @RequestParam String password){
		
		
		System.out.println(username);
		System.out.println(password);
		ModelAndView model = new ModelAndView();
		
		if(username.equals("a") &&  password.equals("a")){
		model.addObject("username", username);
		model.setViewName("success");
		
		}else{
	    model.setViewName("login");
	    model.addObject("message", "Enter Again");
		}
		return model;
	}
	
	// show main menu or show login page again
	
}
