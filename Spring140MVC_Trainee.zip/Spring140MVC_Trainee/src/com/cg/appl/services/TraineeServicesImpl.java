package com.cg.appl.services;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.cg.appl.daos.TraineeDao;
import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeException;


@Service("traineeService")
public class TraineeServicesImpl implements TraineeServices {

	private TraineeDao dao;
	
	@Resource(name="traineeDao")
	public void setTraineeDao(TraineeDao dao){
		this.dao = dao;
	}
	
	@Override
	public Trainee getTraineeDetails(int traineeId) throws TraineeException {
		
		return dao.getTraineeDetails(traineeId);
	}

	@Override
	public List<Trainee> getAllTrainees() throws TraineeException {
		
		return dao.getAllTrainees();
	}

}
