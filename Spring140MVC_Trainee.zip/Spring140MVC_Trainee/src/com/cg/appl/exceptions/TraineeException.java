package com.cg.appl.exceptions;

public class TraineeException extends Exception {

}
